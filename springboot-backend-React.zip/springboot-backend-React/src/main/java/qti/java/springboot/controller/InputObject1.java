package qti.java.springboot.controller;

public class InputObject1 {

}
