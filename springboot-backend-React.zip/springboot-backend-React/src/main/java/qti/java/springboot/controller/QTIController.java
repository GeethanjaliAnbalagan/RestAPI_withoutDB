package qti.java.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/qti")
public class QTIController {

    private final QTIItemService qtiItemService;

    @Autowired
    public QTIController(QTIItemService qtiItemService) {
        this.qtiItemService = qtiItemService;
    }

    @PostMapping("/create")
    public ResponseEntity<QTIItem> createQTIItem(@RequestBody QTIItem qtiItem) {
        QTIItem createdItem = qtiItemService.createQTIItem(qtiItem);
        return ResponseEntity.ok(createdItem);
    }

    @GetMapping("/{id}")
    public ResponseEntity<QTIItem> getQTIItem(@PathVariable String id) {
        QTIItem qtiItem = qtiItemService.getQTIItem(id);
        if (qtiItem != null) {
            return ResponseEntity.ok(qtiItem);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<QTIItem> updateQTIItem(@PathVariable String id, @RequestBody QTIItem updatedQTIItem) {
        try {
            QTIItem updatedItem = qtiItemService.updateQTIItem(id, updatedQTIItem);
            return ResponseEntity.ok(updatedItem);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQTIItem(@PathVariable String id) {
        qtiItemService.deleteQTIItem(id);
        return ResponseEntity.noContent().build();
    }
}