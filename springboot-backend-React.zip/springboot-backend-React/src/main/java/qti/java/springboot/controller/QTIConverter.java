package qti.java.springboot.controller;

public interface QTIConverter {

	String convertToQTI(Object input);
}
