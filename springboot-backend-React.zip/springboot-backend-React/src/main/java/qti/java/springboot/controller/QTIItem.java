package qti.java.springboot.controller;

public class QTIItem {
    private String id;
    private String content;
	
    
 // Constructors, getters, and setters
    
    public QTIItem() {
    	
    }
    
  
	public QTIItem(String id, String content) {
	super();
	this.id = id;
	this.content = content;
     }
	
	  public String getId() {
			return id;
		}
	  
	public void setId(String id) {
		this.id = id;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

    
     
    // Add any other properties as needed
}