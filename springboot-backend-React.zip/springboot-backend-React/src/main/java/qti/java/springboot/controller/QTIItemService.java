package qti.java.springboot.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
@Service
public class QTIItemService {
    private Map<String, QTIItem> qtiItems = new HashMap<>();

    public QTIItem createQTIItem(QTIItem qtiItem) {
        // Generate a unique ID (you may use a UUID for more robust solutions)
        String id = String.valueOf(System.currentTimeMillis());
        qtiItem.setId(id);

        // Save the QTIItem
        qtiItems.put(id, qtiItem);

        return qtiItem;
    }

    public QTIItem getQTIItem(String id) {
        return qtiItems.get(id);
    }

    public QTIItem updateQTIItem(String id, QTIItem updatedQTIItem) {
        if (qtiItems.containsKey(id)) {
            updatedQTIItem.setId(id);
            qtiItems.put(id, updatedQTIItem);
            return updatedQTIItem;
        } else {
            throw new IllegalArgumentException("QTIItem with ID " + id + " not found");
        }
    }

    public void deleteQTIItem(String id) {
        qtiItems.remove(id);
    }
}